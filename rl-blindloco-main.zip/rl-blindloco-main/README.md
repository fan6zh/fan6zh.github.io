# Project page for Science Robotics paper "Learning Quadrupedal Locomotion over Challenging Terrain"
### Author: Joonho Lee (jolee@ethz.ch)
### https://leggedrobotics.github.io/rl-blindloco
